@echo off
title Instalador Automatico - Area Segura 2
echo.
echo   Instalando o Area Segura 2 nesta maquina...
echo   NAO feche esta janela nem desligue o computador.
echo.
echo   Se aparecer uma tela pedindo senha de Administrador, digite a senha
echo   de administrador e confirme - e a unica coisa que precisa fazer aqui.
echo.
echo   O computador vai reiniciar sozinho quando terminar (leva menos de um
echo   minuto). Depois disso ja pode testar com a conta do aluno normalmente.
echo.
start /wait "" "%~dp0Instalar2.exe" -Silent
